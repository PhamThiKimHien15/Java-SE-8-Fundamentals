package jUnit;

import static org.junit.Assert.*;

import org.junit.Test;

import phamThiKimHien.Bai2;

public class TestBai2 {

	// test ham tong tien, hàm tính tiền nước không test vì trong hàm có phần nhập thêm
	//
	@Test
	public void test1() {
		double ex = 42400;
		double ac = phamThiKimHien.Bai2.tongTien(2, 8);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void test2() {
		double ex = 174400;
		double ac = phamThiKimHien.Bai2.tongTien(2, 20);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void test3() {
		double ex = 73000;
		double ac = phamThiKimHien.Bai2.tongTien(2, 11);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void test4() {
		double ex = 89000;
		double ac = phamThiKimHien.Bai2.tongTien(2, 16);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void test5() {
		double ex = 80000;
		double ac = phamThiKimHien.Bai2.tongTien(3, 24);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void test6() {
		double ex = 110000;
		double ac = phamThiKimHien.Bai2.tongTien(4, 50);
		assertEquals(ex, ac, 0);
	}
	
}
