package jUnit;

import static org.junit.Assert.*;

import org.junit.Test;

import phamThiKimHien.Bai4;

public class TestBai4 {

	@Test
	public void testDiemTB1() {
		double ex = 8;
		int[] arr = { 7, 8, 9 };
		double ac = phamThiKimHien.Bai4.tinhDiemTB(arr);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testDiemTB2() {
		double ex = 5.66;
		int[] arr = { 7, 8, 9, 7 ,0, 3 };
		double ac = phamThiKimHien.Bai4.tinhDiemTB(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemTB3() {
		double ex = 8;
		int[] arr = { 7, 8, 9, 7};
		double ac = phamThiKimHien.Bai4.tinhDiemTB(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemTB4() {
		double ex = 9;
		int[] arr = { 7, 8, 10,5 };
		double ac = phamThiKimHien.Bai4.tinhDiemTB(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemLonNhat1() {
		double ex = 10;
		int[] arr = { 7, 8, 10,5 };
		double ac = phamThiKimHien.Bai4.timDiemLonNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemLonNhat2() {
		double ex = 9;
		int[] arr = { 7, 8, 9, 7 ,0, 3 };
		double ac = phamThiKimHien.Bai4.timDiemLonNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemLonNhat3() {
		double ex = 9;
		int[] arr = { 7, 8, 10,5 };
		double ac = phamThiKimHien.Bai4.timDiemLonNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemLonNhat4() {
		double ex = 0;
		int[] arr = { 7, 8, 9, 7 ,0, 3 };
		double ac = phamThiKimHien.Bai4.timDiemLonNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemNhoNhat1() {
		double ex = 5;
		int[] arr = { 7, 8, 10,5 };
		double ac = phamThiKimHien.Bai4.timDiemNhoNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemNhoNhat2() {
		double ex = 0;
		int[] arr = { 7, 8, 9, 7 ,0, 3 };
		double ac = phamThiKimHien.Bai4.timDiemNhoNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemNhoNhat3() {
		double ex = 10;
		int[] arr = { 7, 8, 10,5 };
		double ac = phamThiKimHien.Bai4.timDiemNhoNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
	@Test
	public void testDiemNhoNhat4() {
		double ex = 9;
		int[] arr = { 7, 8, 9, 7 ,0, 3 };
		double ac = phamThiKimHien.Bai4.timDiemNhoNhat(arr);
		assertEquals(ex, ac, 0.01);
	}
}
