package jUnit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBai3 {

	@Test
	public void testTongChanCotLe1() {
		double ex = 5;
		int[][] arr = {{3, 5, 6},{5,6,7}};
		double ac = phamThiKimHien.Bai3.tongDongChanCotLe(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongChanCotLe2() {
		double ex = 11;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongDongChanCotLe(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongChanCotLe3() {
		double ex = 18;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongDongChanCotLe(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongChanCotLe4() {
		double ex = 6;
		int[][] arr = {{3, 5, 0},{5,0,7}};
		double ac = phamThiKimHien.Bai3.tongDongChanCotLe(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongDongDauTien1() {
		double ex = 8;
		int[][] arr = {{3, 5, 0},{5,0,7}};
		double ac = phamThiKimHien.Bai3.tongDongDauTien(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongDongDauTien2() {
		double ex = 14;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongDongDauTien(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongDongDauTien3() {
		double ex = 6;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongDongDauTien(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongDongDauTien4() {
		double ex = 10;
		int[][] arr = {{3, 5, 0},{5,0,7}};
		double ac = phamThiKimHien.Bai3.tongDongDauTien(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongCotCuoi1() {
		double ex = 7;
		int[][] arr = {{3, 5, 0},{5,0,7}};
		double ac = phamThiKimHien.Bai3.tongCotCuoi(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongCotCuoi2() {
		double ex = 28;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongCotCuoi(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongCotCuoi3() {
		double ex = 20;
		int[][] arr = {{3, 5, 0},{5,0,7}};
		double ac = phamThiKimHien.Bai3.tongCotCuoi(arr, 2, 3);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTongCotCuoi4() {
		double ex = 30;
		int[][] arr = {{3, 5, 6},{5,6,7},{4,6,8},{8,9,7}};
		double ac = phamThiKimHien.Bai3.tongCotCuoi(arr, 4, 3);
		assertEquals(ex, ac, 0);
	}
}
