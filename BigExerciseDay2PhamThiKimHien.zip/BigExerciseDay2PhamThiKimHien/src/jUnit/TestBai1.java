package jUnit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBai1 {

	// hinh thuc 2 vung noi tinh
	@Test
	public void testHinhThuc21() {
		double ex = 50000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(120);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc22() {
		double ex = 55000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(2500);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc23() {
		double ex = 40000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(400);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc24() {
		double ex = 55000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(2800);
		assertEquals(ex, ac, 0);
	}
	// hinh thuc 2 vung ngoai tinh
	@Test
	public void testHinhThucNgoaiTinhVung1() {
		double ex = 70000;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1HinhThuc2(2000);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThucNgoaiTinhVung2() {
		double ex = 77000;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1HinhThuc2(2200);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThucNgoaiTinhVung3() {
		double ex = 77000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(400);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThucNgoaiTinhVung4() {
		double ex = 77000;
		double ac = phamThiKimHien.Bai1.tinhNoiTinh(2800);
		assertEquals(ex, ac, 0);
	}
	// hinh thuc 1 noi tinh
	@Test
	public void testHinhThuc1NoiTinh1() {
		double ex = 18000;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(122);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1NoiTinh2() {
		double ex = 8000;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(40);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1NoiTinh3() {
		double ex = 86100;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(2200);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1NoiTinh4() {
		double ex = 86100;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(2600);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1NoiTinh5() {
		double ex = 23000;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(40);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1NoiTinh6() {
		double ex = 37600;
		double ac = phamThiKimHien.Bai1.tinhEMSNoiTinh(200);
		assertEquals(ex, ac, 0);
	}
	// hinh thuc 1 lien tinh
	@Test
	public void testHinhThuc1LienTinh1() {
		double ex = 8500;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(40);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1LienTinh2() {
		double ex = 37500;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(220);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1LienTinh3() {
		double ex = 186300;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(2200);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1LienTinh4() {
		double ex = 186300;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(2600);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1LienTinh5() {
		double ex = 37000;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(200);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testHinhThuc1LienTinh6() {
		double ex = 10;
		double ac = phamThiKimHien.Bai1.tinhEMSVung1(40);
		assertEquals(ex, ac, 0);
	}
}
