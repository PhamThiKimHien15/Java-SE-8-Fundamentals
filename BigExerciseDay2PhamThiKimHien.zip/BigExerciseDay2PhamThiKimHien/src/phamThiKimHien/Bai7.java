package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai7 {

	static BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		String[] mangTu = new String[10];
		try {
			nhapMang(mangTu);
			System.out.println("Trong bo tu nay co 10.\nNhap vi tri muon doan: ");
			int viTri = Integer.parseInt(nhap.readLine());
			if(viTri < 0 || viTri > 9) throw new ArrayIndexOutOfBoundsException("ban nhap khong phu hop");
			thongBao(mangTu, viTri);		
		} catch (NumberFormatException | IOException | ArrayIndexOutOfBoundsException e) {
			System.err.println(e.getMessage());
		}		
	}
	public static void thongBao(String[] mangTu, int viTri) throws IOException {
		String kyTu = "";
		String[] chuoi = new String[mangTu[viTri].length()];
		String[] mangTam;
		int lanChoi = 1;		
		System.out.print("o so 1 co " + mangTu[viTri].length() + " ky tu.");
		int dem = 0;
		for (int i = 0; i < mangTu[viTri].length(); i++) {
			chuoi[i] = String.valueOf(mangTu[viTri].charAt(i));
		}
		mangTam = new String[chuoi.length];
		for (int i = 0; i < mangTam.length; i++) {
			mangTam[i] = "*";
		}
		do {
			System.out.print("\nBan hay doan 1 ky tu: ");
			kyTu = nhap.readLine();
			System.out.print("Lan choi " + lanChoi + ": ");
			int soKyTuGiong = 0;
			int demKyTuTrung;
			for (int i = 0; i < chuoi.length; i++) {
				if(kyTu.equals(chuoi[i])){					
					demKyTuTrung = 0;
					for (int j = 0; j < mangTam.length; j++) {
						if(kyTu.equals(mangTam[i])){
							demKyTuTrung++;							
						}							
					}
					if(demKyTuTrung == 0){
						soKyTuGiong++;
						dem++;
						mangTam[i] = chuoi[i];
					}
				}					
			}			
			if(soKyTuGiong != 0)
				System.out.print("Chuc mung ban. Ban co " + soKyTuGiong +" ky tu ");
			else
				System.out.print("Ban da doan sai. Vui long doan lai");
			System.out.print("\nKy tu da duoc giai ma: ");
			for (int i = 0; i < mangTam.length; i++) {
				System.out.print(mangTam[i]);
			}
			lanChoi++;
			continue;			
		} while (dem < chuoi.length);
		System.out.println("\nTong so lan choi cua ban: " + --lanChoi);		
	}
	public static void nhapMang(String[] mangTu) throws IOException {
		for (int i = 0; i < mangTu.length; i++) {
			System.out.println("Phan tu thu " + (i + 1) + ": ");
			mangTu[i] = nhap.readLine();
		}	
	}
}
