package phamThiKimHien;

public class Bai6 {

	public static void main(String[] args) {
		//cau a
		System.out.println("-----------------cau a-----------");
		maTranA();
		//cau b
		System.out.println("-----------------cau b-----------");
		maTranB();
		//cau c
		System.out.println("-----------------cau c-----------");
		maTranC();
		//cau d
		System.out.println("-----------------cau d-----------");
		maTranD();
		//cau e
		System.out.println("-----------------cau e-----------");
		maTranE();
		//cau f
		System.out.println("-----------------cau f-----------");
		maTranF();
		//cau g
		System.out.println("-----------------cau g-----------");
		maTranG();
	}

	private static void maTranG() {
		for (int i = 0; i < 8; i++) {
			int giam = 8 - i;
			for (int j = 0; j < 8; j++) {
				if(j <= (7 - i))
					System.out.print(" " + (giam--) + " ");
				else
					System.out.print("   ");
			}
			System.out.println();
		}
	}

	private static void maTranF() {
		for (int i = 0; i < 8; i++) {
			int dem = 1;
			for (int j = 0; j < 8; j++) {
				if(j >= (7 - i))
					System.out.print(" " + (8 - j) + " ");
				else
					System.out.print("   ");
			}
			System.out.println();
		}
	}

	private static void maTranE() {
		for (int i = 0; i < 8; i++) {
			int dem = 1;
			for (int j = 0; j < 8; j++) {
				if(j >= i)
					System.out.print(" " + (dem++) + " ");
				else
					System.out.print("   ");
			}
			System.out.println();
		}
	}

	private static void maTranD() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if(j <= i)
					System.out.print(" " + (j+1) + " ");
				else
					System.out.print("   ");
			}
			System.out.println();
		}
	}

	private static void maTranC() {
		for (int i = 0; i < 11; i++) {
			for (int j = 0; j < 11; j++) {
				if((j >= (5 - i) && j <= (5 + i) && i < 6) || (j >= (i - 5) && j <= (10 - i + 5) && i > 5) )
					System.out.print(" # ");
				else
					System.out.print("   ");
			}
			System.out.println("\n");
		}
	}

	private static void maTranB() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 11; j++) {
				if(j >= (5 - i) && j <= (5 + i))
					System.out.print(" # ");
				else
					System.out.print("   ");
			}
			System.out.println("\n");
		}
	}

	private static void maTranA() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 11; j++) {
				if(i == 0 || (i <= j && j < 11 - i))
					System.out.print(" # ");
				else
					System.out.print("   ");
			}
			System.out.println("\n");
		}		
	}
}
