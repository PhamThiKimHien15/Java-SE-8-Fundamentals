package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Array;
import java.util.Arrays;

public class Bai3 {

	static BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		try {
			System.out.println("Nhap n: ");
			int n = Integer.parseInt(nhap.readLine());
			System.out.println("Nhap m: ");
			int m = Integer.parseInt(nhap.readLine());
			int[][] arr = new int[n][m];
			nhapMang(arr, n, m);
			xuatMang(arr, n, m);
			// cau a
			System.out.println("--------------cau a----------------");
			System.out.println("Nhap vao 1 cot: ");
			int cot = Integer.parseInt(nhap.readLine());
			if (cot >= m || cot < 0) throw new ArrayIndexOutOfBoundsException("Ban nhap khong dung");
			xepSap(arr, n, m, cot);
			System.out.println("Mang da duoc sap xep theo cot: ");
			xuatMang(arr, n, m);
			// cau b
			System.out.println("--------------cau b----------------");
			double tong = tongDongChanCotLe(arr, n, m);
			System.out.println("Tong dong chan cot le: " + tong);
			// cau c
			System.out.println("---------------cau c----------------");
			thayGiaTri(arr, n, m, -1);
			xuatMang(arr, n, m);
			// cau d
			System.out.println("----------------cau d-----------------");
			double tongDongTien = tongDongDauTien(arr, n, m);
			System.out.println("Tong dong dau tien: " + tongDongTien);
			double tongDongCuoi = tongDongCuoi(arr, n, m);
			System.out.println("Tong dong cuoi cung: " + tongDongCuoi);
			double tongCotDau = tongCotDau(arr, n, m);
			System.out.println("Tong cot dau tien: " + tongCotDau);
			double tongCotCuoi = tongCotCuoi(arr, n, m);
			System.out.println("Tong cot cuoi cung:  " + tongCotCuoi);
			
			// cau e
			System.out.println("-----------------cau e------------------");
			kiemTraSoChinhPhuong(arr, n, m);
			
		} catch (NumberFormatException | IOException | NegativeArraySizeException | ArrayIndexOutOfBoundsException e) {
			System.err.println(e.getMessage());
		}
	}
	public static double tongCotCuoi(int[][] arr, int n, int m) {
		double tong = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (j == (m - 1)){
					tong += arr[i][j];
				}
			}
		}	
		return tong;
	}
	public static double tongCotDau(int[][] arr, int n, int m) {
		double tong = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (j == 0){
					tong += arr[i][j];
				}
			}
		}	
		return tong;
	}
	public static double tongDongCuoi(int[][] arr, int n, int m) {
		double tong = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (i == (n - 1)){
					tong += arr[i][j];
				}
			}
		}	
		return tong;
	}
	public static double tongDongDauTien(int[][] arr, int n, int m) {
		double tong = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (i == 0){
					tong += arr[i][j];
				}
			}
		}	
		return tong;
	}
	public static void kiemTraSoChinhPhuong(int[][] arr, int n, int m) {
		int viTriDong ;
		int viTriCot;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				 double tam = Math.sqrt(arr[i][j]);
				 if(arr[i][j] == Math.pow(tam, 2)){
					 viTriDong = i;
					 viTriCot = j;
					 System.out.println("So chinh phuong: [" + i + "][" + j + "]");
				 }					 
			}
		}
	}
	
	private static void thayGiaTri(int[][] arr, int n, int m, int k) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				int count = 0;
				if(arr[i][j] > 1){
					for (int j2=1; j2<= Math.sqrt(arr[i][j]); j2++){
						if(arr[i][j] % j2 == 0){
							count++;				
						}			
					}
				}	
				if(count == 1){
					arr[i][j] = k;
				}					
			}
		}
	}
	public static double tongDongChanCotLe(int[][] arr, int n, int m) {
		double tong = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (i % 2 == 0 && j % 2 != 0){
					tong += arr[i][j];
				}
			}
		}	
		return tong;
	}
	private static void xepSap(int[][] arr, int n, int m, int cot) {
		int[] mangTam = new int[n];
		int vt = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++){
				if (j == cot){
					mangTam[vt] = arr[i][j];
					vt++;
				}					
			}
		}	
		Arrays.sort(mangTam);
		for (int i = 0; i < n; i++) {
			arr[i][cot] = mangTam[i];		
		}
	}
	private static void xuatMang(int[][] arr, int n, int m) {
		System.out.println("Mang 2 chieu: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("\t" + arr[i][j]);
			}
			System.out.print("\n");
		}
	}
	private static void nhapMang(int[][] arr, int n, int m) throws NumberFormatException, IOException {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("Nhap a[" + i + "][" + j + "] = ");
				arr[i][j] = Integer.parseInt(nhap.readLine());
			}
		}		
	}
}
