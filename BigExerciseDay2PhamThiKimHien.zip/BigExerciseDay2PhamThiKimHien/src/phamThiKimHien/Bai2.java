package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2 {

	static BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		try {
			System.out.println("Nhap so m3 nuoc dung trong thang: ");
			double nuoc = Integer.parseInt(nhap.readLine());
			System.out.println("Chon doi tuong: ");
			System.out.println("1.Doi tuong sinh hoat: ");
			System.out.println("2.Doi tuong khong sinh hoat: ");
			int chon = Integer.parseInt(nhap.readLine());
			double thanhTien = tinhTienNuoc(nuoc, chon);
			System.out.println("thanh tien: " + thanhTien);
		} catch (NumberFormatException | IOException | ArithmeticException e) {
			System.err.println(e.getMessage());
		}
		
	}
	public static double tinhTienNuoc(double nuoc, int chon) throws ArithmeticException, NumberFormatException, IOException {
		double tongTien = 0;
		double tienNuocKhongThueVaPhi = 0;
		double tienThueGTGT = 0;
		double tienPhiBVMT = 0;
		switch (chon) {
		case 1:
			System.out.println("Nhap them so nguoi trong ho gia dinh: ");
			int soNguoi = Integer.parseInt(nhap.readLine());
			if (soNguoi <= 0) throw new ArithmeticException("Ban nhap khong dung");
			tienNuocKhongThueVaPhi = tongTien(soNguoi, nuoc);
			tienThueGTGT = tienNuocKhongThueVaPhi * 0.05;
			tienPhiBVMT = tienNuocKhongThueVaPhi * 0.1;
			tongTien = tienNuocKhongThueVaPhi + tienThueGTGT + tienPhiBVMT;
			break;
		case 2:
			System.out.println("Chon loai:  ");
			System.out.println("1.Don vi san xuat  ");
			System.out.println("2. Co quan, doan the  ");
			System.out.println("3.don vi kinh doanh, dich vu");
			int chonLoai = Integer.parseInt(nhap.readLine());
			if(chonLoai != 1 && chonLoai != 2 && chonLoai != 3) throw new ArithmeticException("Ban chon chua phu hop");
			if(chonLoai == 1){
				tienNuocKhongThueVaPhi = 9600 * nuoc;
				tienThueGTGT = tienNuocKhongThueVaPhi * 0.05;
				tienPhiBVMT = tienNuocKhongThueVaPhi * 0.1;
				tongTien = tienNuocKhongThueVaPhi + tienThueGTGT + tienPhiBVMT;
			}
			else if (chonLoai == 2){
				tienNuocKhongThueVaPhi = 10300 * nuoc;
				tienThueGTGT = tienNuocKhongThueVaPhi * 0.05;
				tienPhiBVMT = tienNuocKhongThueVaPhi * 0.1;
				tongTien = tienNuocKhongThueVaPhi + tienThueGTGT + tienPhiBVMT;
			}else{
				tienNuocKhongThueVaPhi = 16900 * nuoc;
				tienThueGTGT = tienNuocKhongThueVaPhi * 0.05;
				tienPhiBVMT = tienNuocKhongThueVaPhi * 0.1;
				tongTien = tienNuocKhongThueVaPhi + tienThueGTGT + tienPhiBVMT;
			}
			break;
		default:
			throw new ArithmeticException("Ban chon khong phu hop");
		}
		System.out.println("tien nuoc khong thue va phi: " + tienNuocKhongThueVaPhi);
		System.out.println("tien thue GTGT: " + tienThueGTGT);
		System.out.println("tien phi BVMT: " + tienPhiBVMT);
		return tongTien;
	}
	public static double tongTien(int soNguoi, double nuoc) {
		double thanhTien = 0;
		final double TIENCONG1 = 5300;
		final double TIENCONG2 = 10200;
		final double TIENCONG3 = 11400;
		double nuocTrungBinh1Nguoi = (double)(nuoc / soNguoi);
		if(nuocTrungBinh1Nguoi > 6){
			thanhTien = ((nuocTrungBinh1Nguoi - 6)*TIENCONG3 + 2*TIENCONG2 + 4*TIENCONG1)*soNguoi;
		}
		else if(nuocTrungBinh1Nguoi > 4){
			thanhTien = ((nuocTrungBinh1Nguoi - 4)*TIENCONG2 + 4*TIENCONG1)*soNguoi;
		}else{
			thanhTien = nuocTrungBinh1Nguoi * TIENCONG1 * soNguoi;
		}
		return thanhTien;
	}
}
