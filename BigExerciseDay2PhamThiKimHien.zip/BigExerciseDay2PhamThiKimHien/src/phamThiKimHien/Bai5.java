package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai5 {

	public static void main(String[] args) {		
		maTran();		
	}
	private static void maTran() {
		for (int i = 0; i < 8; i++) {
			for (int k = 0; k < 28; k++) {
				System.out.print("--");
			}
			System.out.println();
			for (int j = 0; j < 8; j++) {
				if(i % 2 == 0){
					System.out.print(" | W | ");
				}else{
					System.out.print(" | B | ");
				}
			}
			System.out.println();
			if(i == 7){
				for (int k = 0; k < 28; k++) {
					System.out.print("--");
				}
			}				
		}
		
	}
}
