package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai1 {
	static BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		try {
			System.out.println("Nhap trong luong buu pham(gr): ");
			double trongLuong = Integer.parseInt(nhap.readLine());
			if(trongLuong <= 0) throw new ArithmeticException("Ban nhap khong dung");
			System.out.println("Chon hinh thuc gui: ");
			System.out.println("1.Cuoc EMS thuong");
			System.out.println("2.Cuoc dich vu phat trong ngay");
			System.out.println("3.Cuoc dich vu hoa toc");
			int chon = Integer.parseInt(nhap.readLine());
			double giaCuoc = tinhGiaCuoc(trongLuong, chon);
			System.out.println("Tong tien: " + giaCuoc);
		} catch (NumberFormatException | IOException | ArithmeticException e) {
			System.err.println(e.getMessage());
		}		
	}
	private static double tinhGiaCuoc(double trongLuong, int chon) throws ArithmeticException, NumberFormatException, IOException {
		int eMS, eMSLienTinh, eMSLienTinhVung;
		double thanhTien = 0;
		switch (chon) {
		case 1:
			eMS = chonEMS();			
			if (eMS == 1)
				thanhTien= tinhEMSNoiTinh(trongLuong);	
			else{
				eMSLienTinh = chonEMSLienTinh();
				if (eMSLienTinh == 1)
					thanhTien = tinhEMSVung1(trongLuong);
				else if (eMSLienTinh == 2){
					eMSLienTinhVung = chonEMSLienTinhVung();
					if(eMSLienTinhVung == 1)
						thanhTien = tinhEMSVung21(trongLuong);
					else
						thanhTien = tinhEMSVung22(trongLuong);					
				}else{
					thanhTien = tinhEMSVung3(trongLuong);
				}
			}
			break;
		case 2:
			eMS = chonEMS();
			if (eMS == 1)
				thanhTien= tinhNoiTinh(trongLuong);	
			else{
				eMSLienTinh = chonEMSLienTinhHinhThuc2();
				if (eMSLienTinh == 1)
					thanhTien = tinhEMSVung1HinhThuc2(trongLuong);
				else {
					eMSLienTinhVung = chonEMSLienTinhVung();
					if(eMSLienTinhVung == 1)
						thanhTien = tinhEMSVung21HinhThuc2(trongLuong);
					else
						thanhTien = tinhEMSVung22HinhThuc2(trongLuong);					
				}
			}				
			break;
		case 3:
			eMS = chonEMS();
			if (eMS == 1)
				thanhTien= tinhNoiTinh(trongLuong);	
			else{
				eMSLienTinh = chonEMSLienTinh();
				if (eMSLienTinh == 1)
					thanhTien = tinhEMSVung1HinhThuc2(trongLuong);
				else if (eMSLienTinh == 2){
					eMSLienTinhVung = chonEMSLienTinhVung();
					if(eMSLienTinhVung == 1)
						thanhTien = tinhEMSVung21HinhThuc3(trongLuong);
					else
						thanhTien = tinhEMSVung22HinhThuc3(trongLuong);					
				}else{
					thanhTien = tinhEMSVung3HinhThuc3(trongLuong);
				}
			}	
			break;
		default:
			throw new ArithmeticException("Ban chon khong phu hop.");
		}
		return thanhTien;
	}
	
	public static int chonEMSLienTinhHinhThuc2() throws ArithmeticException, NumberFormatException, IOException {
		System.out.println("Chon EMS lien tinh:"); 
		System.out.println("1.Vung 1");
		System.out.println("2.Vung 2");
		int chon = Integer.parseInt(nhap.readLine());
		if(chon != 1 && chon != 2) throw new ArithmeticException("Ban chon khong phu hop");
		return chon;
	}
	public static double tinhEMSVung3HinhThuc3(double trongLuong) {
		final double NOITINH1 = 110000;
		final double NOITINH2 = 15000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhEMSVung22HinhThuc3(double trongLuong) {
		final double NOITINH1 = 100000;
		final double NOITINH2 = 12000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhEMSVung22HinhThuc2(double trongLuong) {
		final double NOITINH1 = 130000;
		final double NOITINH2 = 20000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhEMSVung21HinhThuc3(double trongLuong) {
		final double NOITINH1 = 85000;
		final double NOITINH2 = 10000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhEMSVung21HinhThuc2(double trongLuong) {
		final double NOITINH1 = 110000;
		final double NOITINH2 = 12000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhEMSVung1HinhThuc2(double trongLuong) {
		final double NOITINH1 = 70000;
		final double NOITINH2 = 7000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhNoiTinh(double trongLuong) {
		final double NOITINH1 = 50000;
		final double NOITINH2 = 5000;
		double thanhTien = tinhTienMuc23(trongLuong, NOITINH1, NOITINH2);
		return thanhTien;
	}
	public static double tinhTienMuc23(double trongLuong, double NOITINH1, double NOITINH2) {
		double thanhTien;
		if (trongLuong > 2000){
			thanhTien = Math.ceil((trongLuong - 2000)/500)*NOITINH2 + NOITINH1;
		}
		else {
			thanhTien = NOITINH1;
		}
		return thanhTien;
	}
	public static double tinhEMSVung3(double trongLuong) {
		final double NOITINH1 = 10000;
		final double NOITINH2 = 14000;
		final double NOITINH3 = 22500;
		final double NOITINH4 = 29500;
		final double NOITINH5 = 43500;
		final double NOITINH6 = 55500;
		final double NOITINH7 = 67500;
		final double NOITINH8 = 9500;
		double thanhTien = tinhTien(trongLuong, NOITINH1, NOITINH2, NOITINH3, NOITINH4, NOITINH5, NOITINH6, NOITINH7, NOITINH8);
		return thanhTien;
	}
	public static double tinhEMSVung22(double trongLuong) {
		final double NOITINH1 = 9500;
		final double NOITINH2 = 13500;
		final double NOITINH3 = 21500;
		final double NOITINH4 = 28000;
		final double NOITINH5 = 40500;
		final double NOITINH6 = 52500;
		final double NOITINH7 = 63500;
		final double NOITINH8 = 8500;
		double thanhTien = tinhTien(trongLuong, NOITINH1, NOITINH2, NOITINH3, NOITINH4, NOITINH5, NOITINH6, NOITINH7, NOITINH8);
		return thanhTien;
	}
	public static double tinhEMSVung21(double trongLuong) {
		final double NOITINH1 = 9500;
		final double NOITINH2 = 13500;
		final double NOITINH3 = 20000;
		final double NOITINH4 = 26500;
		final double NOITINH5 = 38500;
		final double NOITINH6 = 49500;
		final double NOITINH7 = 59500;
		final double NOITINH8 = 8500;
		double thanhTien = tinhTien(trongLuong, NOITINH1, NOITINH2, NOITINH3, NOITINH4, NOITINH5, NOITINH6, NOITINH7, NOITINH8);
		return thanhTien;
	}
	public static int chonEMSLienTinhVung() throws ArithmeticException, NumberFormatException, IOException {
		System.out.println("Chon EMS lien tinh vung:"); 
		System.out.println("1.Tu Da Nang di HN, TP.HCM va nguoc lai");
		System.out.println("2.HN di TP.HCM va nguoc lai.");
		int chon = Integer.parseInt(nhap.readLine());
		if(chon != 1 && chon != 2) throw new ArithmeticException("Ban chon khong phu hop");
		return chon;
	}
	public static double tinhEMSVung1(double trongLuong) {
		final double NOITINH1 = 8500;
		final double NOITINH2 = 12500;
		final double NOITINH3 = 16500;
		final double NOITINH4 = 23500;
		final double NOITINH5 = 33000;
		final double NOITINH6 = 40000;
		final double NOITINH7 = 48500;
		final double NOITINH8 = 3800;
		double thanhTien = tinhTien(trongLuong, NOITINH1, NOITINH2, NOITINH3, NOITINH4, NOITINH5, NOITINH6, NOITINH7, NOITINH8);
		return thanhTien;
	}
	public static double tinhTien(double trongLuong, double NOITINH1, double NOITINH2, double NOITINH3, double NOITINH4,
			double NOITINH5, double NOITINH6, double NOITINH7, double NOITINH8) {
		double thanhTien;
		if (trongLuong > 2000){
			thanhTien = Math.ceil((trongLuong - 2000)/500)*NOITINH8 + NOITINH7 + NOITINH6 + NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 1500){
			thanhTien = NOITINH7 + NOITINH6 + NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 1000){
			thanhTien = NOITINH6 + NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 500){
			thanhTien = NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 250){
			thanhTien = NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 100){
			thanhTien = NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong > 50){
			thanhTien = NOITINH2 + NOITINH1;
		}
		else{
			thanhTien = NOITINH1;
		}
		return thanhTien;
	}
	public static int chonEMSLienTinh() throws ArithmeticException, NumberFormatException, IOException {
		System.out.println("Chon EMS lien tinh:"); 
		System.out.println("1.Vung 1");
		System.out.println("2.Vung 2");
		System.out.println("3.Vung 3");
		int chon = Integer.parseInt(nhap.readLine());
		if(chon != 1 && chon != 2 && chon != 3) throw new ArithmeticException("Ban chon khong phu hop");
		return chon;
	}
	public static double tinhEMSNoiTinh(double trongLuong) {
		final double NOITINH1 = 8000;
		final double NOITINH2 = 10000;
		final double NOITINH3 = 12500;
		final double NOITINH4 = 15000;
		final double NOITINH5 = 18000;
		final double NOITINH6 = 21000;
		final double NOITINH7 = 1600;		
		double thanhTien;
		if (trongLuong > 2000){
			thanhTien = Math.ceil((trongLuong - 2000) / 500)*NOITINH7 + NOITINH6 + NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;
		}
		else if (trongLuong >1500){
			thanhTien = NOITINH6 + NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;	
		}
		else if (trongLuong > 1000){
			thanhTien = NOITINH5 + NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;	
		}
		else if (trongLuong > 500){
			thanhTien = NOITINH4 + NOITINH3 + NOITINH2 + NOITINH1;	
		}
		else if (trongLuong > 250){
			thanhTien = NOITINH3 + NOITINH2 + NOITINH1;	
		}
		else if (trongLuong > 100){
			thanhTien = NOITINH2 + NOITINH1;	
		}
		else{
			thanhTien = NOITINH1;
		}
		return thanhTien;
	}
	public static int chonEMS() throws ArithmeticException, NumberFormatException, IOException {
		System.out.println("Chon EMS:"); 
		System.out.println("1.Noi tinh");
		System.out.println("2.Lien tinh");
		int chonEMS;
		chonEMS = Integer.parseInt(nhap.readLine());
		if(chonEMS != 1 && chonEMS != 2) throw new ArithmeticException("Ban chon khong phu hop");
		return chonEMS;
	}
	
}
