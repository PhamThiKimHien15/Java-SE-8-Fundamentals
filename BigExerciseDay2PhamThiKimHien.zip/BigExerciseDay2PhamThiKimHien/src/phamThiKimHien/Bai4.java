package phamThiKimHien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai4 {

	static BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		try {
			System.out.println("nhap so luong sinh vien n: ");
			int n = Integer.parseInt(nhap.readLine());
			int[] sinhVen = new int[n];
			nhapDiem(sinhVen, n);
			double diemTB = tinhDiemTB(sinhVen);
			System.out.println("Diem trung binh: " + String.format("%.2f", diemTB));
			double diemLonNhat = timDiemLonNhat(sinhVen);
			System.out.println("Diem lon nhat: " + diemLonNhat);
			double diemNhoNhat = timDiemNhoNhat(sinhVen);
			System.out.println("Diem nho nhat: " + diemNhoNhat);
		} catch (NumberFormatException | IOException | NegativeArraySizeException e) {
			System.err.println(e.getMessage());
		}		
	}
	public static double timDiemNhoNhat(int[] sinhVen) {
		double diemNhoNhat = sinhVen[0];
		for (int i = 0; i < sinhVen.length; i++) {
			if(diemNhoNhat > sinhVen[i]){
				diemNhoNhat = sinhVen[i];
			}
		}
		return diemNhoNhat;
	}
	public static double timDiemLonNhat(int[] sinhVen) {
		double diemLonNhat = sinhVen[0];
		for (int i = 0; i < sinhVen.length; i++) {
			if(diemLonNhat < sinhVen[i]){
				diemLonNhat = sinhVen[i];
			}
		}
		return diemLonNhat;
	}
	public static double tinhDiemTB(int[] sinhVen) {
		double tong = 0;
		double diemTB = 0;
		for (int i = 0; i < sinhVen.length; i++) {
			tong += sinhVen[i];
		}
		diemTB = tong / sinhVen.length;
		return diemTB;
	}
	private static void nhapDiem(int[] sinhVen, int n) throws  IOException {
		for (int i = 0; i < sinhVen.length; i++) {
			System.out.println("Sinh vien " + (i+1));
			sinhVen[i] = Integer.parseInt(nhap.readLine());
			if (sinhVen[i] < 0 || sinhVen[i] > 10){
				System.out.println("Ban nhap khong dung. Vui long nhap lai");
				System.out.println("Sinh vien " + (i+1));
				sinhVen[i] = Integer.parseInt(nhap.readLine());
				continue;
			}
		}
		
	}
}
