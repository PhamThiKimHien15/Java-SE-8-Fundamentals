import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai4_2 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		final float giaMoCua = 11000;
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap loai xe (4 hoac 7): ");
		int soCho = Integer.parseInt(inp.readLine());
		System.out.println("Nhap so km: ");
		float km= Float.parseFloat(inp.readLine());
		
		if (soCho == 7 || soCho ==4){
			if (km <= 0.8)
				System.out.println("Thanh tien = "+ String.format("%.1f", giaMoCua));
			else if(soCho == 7){	
				if (km > 30){
					float thanhtien = (float) ((km - 30.8)*14400 +(30 - 0.8)*17000 + giaMoCua); 
					System.out.println("Thanh tien = "+ String.format("%.1f", thanhtien));
				
				}
				else if (km > 0.8){
					float thanhtien = (float) ((km - 0.8)*17000 + giaMoCua); 
					System.out.println("Thanh tien = "+ String.format("%.1f", thanhtien));
				}
				
			}else{
				if (km > 30){
					float thanhtien = (float) ((km - 30.8)*12400 +(30 - 0.8)*16500 + giaMoCua); 
					System.out.println("Thanh tien = "+ String.format("%.1f", thanhtien));
				
				}
				else if (km > 0.8){
					float thanhtien = (float) ((km - 0.8)*16500 + giaMoCua); 
					System.out.println("Thanh tien = "+ String.format("%.1f", thanhtien));
				}
			}
		}else{
			System.out.println("Vui long nhap 4 cho hay 7 cho.");
		}
		
		
		
		
	}
}
