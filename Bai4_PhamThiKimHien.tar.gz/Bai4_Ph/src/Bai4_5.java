import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Bai4_5 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap thang: ");
		int thang = Integer.parseInt(inp.readLine());
		System.out.println("Nhap nam: ");
		int nam = Integer.parseInt(inp.readLine());
		System.out.println("Nhap ngay: ");
		int ngay = Integer.parseInt(inp.readLine());
		int soNgay = 0;
		switch (thang) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			soNgay = 31;
			System.out.println("So ngay: " + soNgay );
			if (ngay == 31 && thang !=12){
				System.out.println("Ngay hom sau cua ngay da nhap la: 1 thang "+ (thang+1));
				
			}
			else if (ngay == 31 && thang ==12){
				System.out.println("Ngay hom sau cua ngay da nhap la:1 thang 1 nam "+ (nam+1));
			}else {
				System.out.println("Ngay hom sau cua ngay da nhap la: "+ (ngay+1) + "/" + thang + "/" +nam);
			}
			if (ngay == 31 && ngay != 1){
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay:  "+ (ngay-1) + "/" + thang);
				
			}else if (ngay == 1 && thang != 1){
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay 1 thang  "+ (thang-1));		
			}
			else if (ngay == 1 && thang == 1){
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay 31 thang 12  "+ (nam-1));		

			}
			break;
		case 4:
		case 6:
		case 9:
		case 11:		
			soNgay = 30;
			System.out.println("So ngay: " + soNgay );
			if (ngay == 31 ){
				System.out.println("Ngay hom sau cua ngay da nhap la:1 thang "+ (thang+1));
			}else {
				System.out.println("Ngay hom sau cua ngay da nhap la: "+ (ngay+1) + "/" + thang + "/" +nam);
			}
			if (ngay != 1 ){
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay:  "+ (ngay-1) + "/" + thang);
				
			}else {
				System.out.println("Ngay hom truoc cua ngay da nhap la ngay 1 thang  "+ (thang-1));		
			}
			
			break;
		case 2:			
			if((nam % 4 == 0) && !(nam %100 == 0) || (nam %400 == 0)){
				soNgay = 29;
				System.out.println("So ngay: " + soNgay );
				if (ngay == 29 ){
					System.out.println("Ngay hom sau cua ngay da nhap la:1 thang "+ (thang+1));
				}else {
					System.out.println("Ngay hom sau cua ngay da nhap la: "+ (ngay+1) + "/" + thang + "/" +nam);
				}
				if (ngay != 1 ){
					System.out.println("Ngay hom truoc cua ngay da nhap la ngay:  "+ (ngay-1) + "/" + thang);
					
				}else {
					System.out.println("Ngay hom truoc cua ngay da nhap la ngay 1 thang  "+ (thang-1));		
				}
			}else {
				soNgay = 28;
				System.out.println("So ngay: " + soNgay );
				if (ngay == 28 ){
					System.out.println("Ngay hom sau cua ngay da nhap la:1 thang "+ (thang+1));
				}else {
					System.out.println("Ngay hom sau cua ngay da nhap la: "+ (ngay+1) + "/" + thang + "/" +nam);
				}
				if (ngay != 1 ){
					System.out.println("Ngay hom truoc cua ngay da nhap la ngay:  "+ (ngay-1));
					
				}else {
					System.out.println("Ngay hom truoc cua ngay da nhap la ngay 1 thang  "+ (thang-1));		
				}
			}
			break;
		default:
			System.out.println("Ban nhap thang sai.");
			break;
		}
		
		
		
		
		
		
	}
}
