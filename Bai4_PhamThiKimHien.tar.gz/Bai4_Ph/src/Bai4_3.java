import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai4_3 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		final float bac1= 1388;
		final float bac2=1433;
		final float bac3= 1660;
		final float bac4=2082;
		final float bac5=2324;
		final float bac6=2399;
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so KW tieu thu: ");
		float kw = Float.parseFloat(inp.readLine());
		double thanhTien;
		if (kw > 400){
			thanhTien= (kw - 400)*bac6+ 100*bac5 + 100*bac4 + 100*bac3+50*bac2 + 50*bac1;
			System.out.println("Thanh tien = " + String.format("%.1f", thanhTien));
		}
		else if (kw > 300 ){
			thanhTien= (kw - 300)*bac5 + 100*bac4 + 100*bac3+50*bac2 + 50*bac1;
			System.out.println("Thanh tien = " + String.format("%.1f", thanhTien));
		}
		else if (kw > 200 ){
			thanhTien= (kw - 200)*bac4 + 100*bac3+50*bac2 + 50*bac1;
			System.out.println("Thanh tien = " + String.format("%.1f", thanhTien));
		}
		else if (kw > 100 ){
			thanhTien= (kw - 100)*bac3+50*bac2 + 50*bac1;
			System.out.println("Thanh tien = " + String.format("%.1f", thanhTien));
		}
		else if (kw > 50 && kw <=100){
			thanhTien=(kw - 50)*bac2 + 50*bac1;
			System.out.println("Thanh tien = " + String.format("%.1f", thanhTien));
		}else{
			System.out.println("Thanh tien = " + String.format("%.1f", bac1));
		}
				
	}
}
