import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai4_4 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		final float giamGia2=(float) 0.25;
		final float giamGia1=(float) 0.3;
		final float gia1=1260000;
		final float gia2=1550000;
		final float gia3=1830000;
		final float gia4=2120000;
		final float gia5=2540000;
		final float gia6=4800000;
		float tienPhong;
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("1.Standard");
		System.out.println("2.Superior Garden V");
		System.out.println("3.Superior Ocean V");
		System.out.println("4.Garden View Bungalow");
		System.out.println("5.Pool View Bungalow");
		System.out.println("6.Family Room");
		System.out.println("7.Beach Front Bungalow");
		System.out.println("8.VIP sea view");
		
		System.out.println("Nhap loai phong: ");
		int loaiPhong= Integer.parseInt(inp.readLine());
		System.out.println("Nhap so dem: ");
		int soDem= Integer.parseInt(inp.readLine());
		switch (loaiPhong) {
		case 1:	
			tienPhong= soDem*gia1;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}else{
				System.out.println("Thanh Tien = " + gia1 );
			}
			break;
		case 2:		
			tienPhong= soDem*gia2;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}else{
				System.out.println("Thanh Tien = " + gia2 );
			}
			break;
		case 3:		
		case 4:	
			tienPhong= soDem*gia3;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}else{
				System.out.println("Thanh Tien = " + gia3 );
			}
			break;
		case 5:	
		case 6:	
			tienPhong= soDem*gia4;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}
			else{
				System.out.println("Thanh Tien = " + gia4 );
			}
			break;
		case 7:	
			tienPhong= soDem*gia5;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}else{
				System.out.println("Thanh Tien = " + gia5 );
			}
			break;
		case 8:
			tienPhong= soDem*gia6;
			if(soDem >= 4){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia1));
			}
			else if(soDem >= 2 ){
				System.out.println("Thanh Tien = " + (tienPhong - tienPhong*giamGia2));
			}else{
				System.out.println("Thanh Tien = " + gia6 );
			}
			break;
		}
		
	}
}
