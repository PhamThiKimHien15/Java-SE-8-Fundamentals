import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai4_1 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap a: ");
		int a = Integer.parseInt(inp.readLine());
		
		System.out.println("Nhap b: ");
		int b = Integer.parseInt(inp.readLine());
		
		System.out.println("Nhap c: ");
		int c = Integer.parseInt(inp.readLine());
		
		System.out.println("Nhap d: ");
		int d = Integer.parseInt(inp.readLine());
		
		int max = a, min = a;
		if (b>max) max = b;
		if (c>max) max =c;
		if (d>max) max =d;
		
		if(b <min) min = b;
		if (c < min) min =c;
		if (d < min) min =d;
		
		System.out.println("Gia tri nhap vao la: " + String.format("%5s %5s %5s %5s", a, b, c, d));
		System.out.println("So lon nhat: " + max);
		System.out.println("So nho nhat: " + min);
	}
}
