import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Bai11_2_xuLyChuoiStringBuilder {

	public static void xuLyChuoi(StringBuilder sb, StringBuilder sb1, StringBuilder sb2, int viTiChen, int viTriDau, int viTriCuoi) {
		System.out.println("Chieu dai chuoi sb: " + sb.length());
		System.out.println("chuoi sb sau khi noi chuoi s1: " + sb.append(sb1));
		System.out.println("chuoi sb sau khi chen sb2 vao vi tri " + sb.insert(viTiChen, sb2));
		System.out.println("chuoi sb sau khi bi xoa noi dung tu vi tri dau den vi tri cuoi: " + sb.delete(viTriDau, viTriCuoi));
		System.out.println("chuoi sb sau khi dao nguoc: " + sb.reverse());
	}
	public static void main(String[] args) {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Nhap chuoi sb: ");
			StringBuilder sb = new StringBuilder(nhap.readLine());
			System.out.println("Nhap chuoi sb1: ");
			StringBuilder sb1 = new StringBuilder(nhap.readLine());
			System.out.println("Nhap chuoi sb2: ");
			StringBuilder sb2 = new StringBuilder(nhap.readLine());
			System.out.println("Nhap vi tri chen: ");
			int viTriChen = Integer.parseInt(nhap.readLine());
			System.out.println("Nhap vi tri dau: ");
			int viTriDau = Integer.parseInt(nhap.readLine());
			System.out.println("Nhap vi tri cuoi: ");
			int viTriCuoi = Integer.parseInt(nhap.readLine());
			xuLyChuoi(sb, sb1, sb2, viTriChen, viTriDau, viTriCuoi);
		} catch (IOException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
	}
}
