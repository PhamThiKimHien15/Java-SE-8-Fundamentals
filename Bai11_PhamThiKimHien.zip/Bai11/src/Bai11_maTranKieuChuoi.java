public class Bai11_maTranKieuChuoi {

	public static void maTranA() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

	public static void maTranB() {
		for (int i = 8; i > 0; i--) {
			for (int j = i; j > 0; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

	public static void maTranC() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (i <= j)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void maTranD() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8 ; j++) {
				if (i + j < 7)
					System.out.print(" ");
				else
					System.out.print("*");
			}
			System.out.println();
		}
	}
	public static void maTranE() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 || i == 6 || j == 0 || j == 6)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void maTranF() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 || i == 6 || i == j)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void maTranG() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 || i == 6 || i + j == 6)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void maTranH() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 || i == 6 || i + j == 6 || i == j)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void maTranI() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 || i == 6 || i + j == 6 || i == j || j == 0 || j == 6)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		System.out.println("Ma tran A: ");
		maTranA();
		System.out.println("Ma tran B: ");
		maTranB();
		System.out.println("Ma tran C: ");
		maTranC();
		System.out.println("Ma tran D: ");
		maTranD();
		System.out.println("Ma tran E: ");
		maTranE();
		System.out.println("Ma tran F: ");
		maTranF();
		System.out.println("Ma tran G: ");
		maTranG();
		System.out.println("Ma tran H: ");
		maTranH();
		System.out.println("Ma tran I: ");
		maTranI();
	}
}
