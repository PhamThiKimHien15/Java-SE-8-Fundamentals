import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Bai11_xuLyChuoiStringBuilder {

	public static void inTungKyTu(StringBuilder sb) {
		for (int i = 0; i < sb.length(); i++) {
			System.out.println(sb.charAt(i));
		}
	}
	public static void kiemTraChuoi(StringBuilder sb, StringBuilder kt) {
		int viTri = -1;
		viTri= sb.indexOf(kt.toString());
		if(viTri != -1)
			System.out.println(kt + " xuat hien tai vi tri: " + viTri);
		else
			System.out.println("Khong tim thay vi tri cua " + kt);
	}
	public static void main(String[] args) {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Nhap chuoi sb: ");
			StringBuilder sb = new StringBuilder(nhap.readLine());
			System.out.println("Tung ky tu trong chuoi: ");
			inTungKyTu(sb);
			System.out.println("Nhap chuoi kt: ");
			StringBuilder kt = new StringBuilder(nhap.readLine());
			kiemTraChuoi(sb, kt);
		} catch (IOException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
	}
}
