import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;


public class Bai11_xuLyMangChuoi {

	public static void xuatMang(String[] mangTen) {
		String rs = "";
		for(String value: mangTen){
			rs += " " + value;
		}
		System.out.println(rs);
	}
	public static void kiemTraTen(String[] mangTen, String ten) {
		int count = 0;
		int viTri = -1;
		for (int i = 0; i < mangTen.length; i++) {
			if(mangTen[i].compareTo(ten) == 0){
				count++;
				viTri = i;
				break;
			}
		}
		if(count != 0){
			System.out.println("Mang chuoi co ten: " + ten + ";\t vi tri: " + viTri);
		}else{
			System.out.println("Khong co ten vua nhap trong mang");
		}
	}
	public static void timPhuTuCoKyTu(String[] mangTen) {
		System.out.print("Mang co phan tu co ky tu n: ");
		int count = 0;
		for (int i = 0; i < mangTen.length; i++) {
			for (int j = 0; j < mangTen[i].length(); j++) {
				if(mangTen[i].charAt(j) == 'n'){
					System.out.print("\t" + mangTen[i]);
					count++;
				}
			}
		}
		if(count == 0)
			System.out.println("khong tim thay");
	}
	public static void main(String[] args) {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Nhap n: ");
			int n = Integer.parseInt(nhap.readLine());
			String[] mangTen = new String[n];
			for (int i = 0; i < n; i++) {
				System.out.println("Nhap chuoi thu " + i);
				mangTen[i] = nhap.readLine();
			}
			System.out.print("Mang vua nhap: ");
			xuatMang(mangTen);
			System.out.println("Nhap ten cua mot nguoi: ");
			String ten = nhap.readLine();
			kiemTraTen(mangTen, ten);
			timPhuTuCoKyTu(mangTen);
			System.out.println("Mang sau khi sap xep: ");
			Arrays.sort(mangTen);
			xuatMang(mangTen);
		} catch (NumberFormatException | IOException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
	}
}
