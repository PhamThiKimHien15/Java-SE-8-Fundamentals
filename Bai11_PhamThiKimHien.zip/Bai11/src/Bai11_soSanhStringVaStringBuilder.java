import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Bai11_soSanhStringVaStringBuilder {
	public static void main(String[] args) {
		String s = "";
		StringBuilder sb = new StringBuilder();
		long thoiGianSBD = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			s = s.concat(i + " ");
		}
		long thoiGianSKT = System.currentTimeMillis();
		long thoiGianSBBD = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			sb = sb.append(i + " ");
		}
		long thoiGianSBKT = System.currentTimeMillis();
		
		System.out.println("Chieu dai chuoi String s: " + s.length());
		System.out.println("Chieu dai chuoi String sb: " + sb.length());
		long thoiGianS = thoiGianSKT - thoiGianSBD;
		long thoiGianSB = thoiGianSBKT - thoiGianSBBD;
		System.out.println("Thoi gian thuc hien s: " + thoiGianS + " milisecond");
		System.out.println("thoiGianSBBD gian thuc hien sb: " + thoiGianSB + " milisecond");
		if (thoiGianS > thoiGianSB)
			System.out.println("Thoi gian s dai hon sb");
		else
			System.out.println("Thoi gian sb dai hon s");
	}
}
