import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Bai11_1_xuLyChuoi {

	public static void xuLyChuoi(String s1, String s2, String s3, int v) {
		System.out.println("Chieu dai chuoi s1: " + s1.length());
		System.out.println("Chieu dai chuoi s2: " + s2.length());
		System.out.println("Chieu dai chuoi s3: " + s3.length());
		System.out.println("So sanh s1 va s2: " + s1.compareTo(s2));
		System.out.println("Vi tri xuat hien dau tien cua chuoi s3 trong s1: " + s1.indexOf(s3));
		String s4 = s1.substring(v);
		System.out.println("Chuoi s4: " + s4);
	}
	public static void main(String[] args) {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Nhap chuoi s1: ");
			String s1 = nhap.readLine();
			System.out.println("Nhap chuoi s2: ");
			String s2 = nhap.readLine();
			System.out.println("Nhap chuoi s3: ");
			String s3 = nhap.readLine();
			System.out.println("Nhap vi tri v: ");
			int v = Integer.parseInt(nhap.readLine());
			xuLyChuoi(s1, s2, s3, v);
		} catch (IOException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
	}
}
