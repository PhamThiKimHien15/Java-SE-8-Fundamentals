
public class Bai11_soSanhStringBuilderTuCharVaString {

	public static void main(String[] args) {
		char a1 = 'A';
		String a2 = "A";
		StringBuilder sb1 = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();
		long thoiGianSB1BD = System.currentTimeMillis();
		for (int i = 0; i < 1000000; i++) {
			sb1 = sb1.append(a1);
		}
		long thoiGianSB1KT = System.currentTimeMillis();
		long thoiGianSB2BD = System.currentTimeMillis();
		for (int i = 0; i < 1000000; i++) {
			sb2 = sb2.append(a2);
		}
		long thoiGianSB2KT = System.currentTimeMillis();
		
		System.out.println("Chieu dai chuoi String sb1: " + sb1.length());
		System.out.println("Chieu dai chuoi String sb2: " + sb2.length());
		long thoiGianSB1 = thoiGianSB1KT - thoiGianSB1BD;
		long thoiGianSB2 = thoiGianSB2KT - thoiGianSB2BD;
		System.out.println("Thoi gian thuc hien sb1: " + thoiGianSB1 + " milisecond");
		System.out.println("thoi gian thuc hien sb2: " + thoiGianSB2 + " milisecond");
		if (thoiGianSB1 > thoiGianSB2)
			System.out.println("Thoi gian them char dai hon them String");
		else
			System.out.println("Thoi gian them String dai hon them char");
	}
}
