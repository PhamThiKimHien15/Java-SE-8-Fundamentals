package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

import KimHien.BMI;

public class TestBMI {
	BMI b = new BMI();
	@Test
	public void testBMI1() {
		double ex = 18.73;
		double kq = b.tinhBMI(1.55, 45);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI2() {
		double ex = 19.53125;
		double kq = b.tinhBMI(1.6, 50);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI3() {
		double ex = 20.20;
		double kq = b.tinhBMI(1.65, 55);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI4() {
		double ex = 20.761246;
		double kq = b.tinhBMI(1.7, 60);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI5() {
		double ex = 21.20;
		double kq = b.tinhBMI(1.75, 65);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI6() {
		double ex = 13.333333;
		double kq = b.tinhBMI(1.5, 30);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI7() {
		double ex = 16.17;
		double kq = b.tinhBMI(1.45, 34);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI8() {
		double ex = 20.41;
		double kq = b.tinhBMI(1.4, 40);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI9() {
		double ex = 13.71;
		double kq = b.tinhBMI(1.35, 25);
		assertEquals(ex, kq, 0.01);
	}
	@Test
	public void testBMI10() {
		double ex = 11.83432;
		double kq = b.tinhBMI(1.3, 20);
		assertEquals(ex, kq, 0.01);
	}

}
