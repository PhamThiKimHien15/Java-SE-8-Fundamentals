package Testing;


import static org.junit.Assert.*;

import org.junit.Test;

import KimHien.Luong;

public class TestLuong {
	Luong luong = new Luong();
	
	@Test
	public void testLuong1() {
		double ex = 3041000;
		double kq = luong.tinhLuong(2.34, 1150000, 100000, 250000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong2() {
		double ex = 3800000;
		double kq = luong.tinhLuong(3, 1150000, 150000, 250000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong3() {
		double ex = 4329500;
		double kq = luong.tinhLuong(3.33, 1150000, 200000, 300000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong4() {
		double ex = 4800000;
		double kq = luong.tinhLuong(3.36, 1150000, 300000, 300000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong5() {
		double ex = 5338500;
		double kq = luong.tinhLuong(3.99, 1150000, 400000, 350000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong6() {
		double ex = 2800000;
		double kq = luong.tinhLuong(2.22, 1150000, 100000, 150000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong7() {
		double ex = 2646000;
		double kq = luong.tinhLuong(2.04, 1150000, 150000, 150000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong8() {
		double ex = 3500000;
		double kq = luong.tinhLuong(2.67, 1150000, 200000, 250000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong9() {
		double ex = 5803000;
		double kq = luong.tinhLuong(4.22, 1150000, 500000, 450000);
		assertEquals(ex, kq, 0);
	}
	@Test
	public void testLuong10() {
		double ex = 6000000;
		double kq = luong.tinhLuong(4.55, 1150000, 300000, 500000);
		assertEquals(ex, kq, 0);
	}
}
