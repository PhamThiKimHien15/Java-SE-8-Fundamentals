package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

import KimHien.PTBac2;

public class TestPTBac2 {
	PTBac2 pt = new PTBac2();
	@Test
	public void testPT1() {
		double[] ex=new double[1];
		ex[0] = -1; 
		double[] kq = pt.tinhPTBac2(0, 0, 5);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT2() {
		double[] ex=new double[1];
		ex[0] = 0;  
		double[] kq = pt.tinhPTBac2(2, 4, 5);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT3() {
		double[] ex=new double[1];
		ex[0] = 0;
		double[] kq = pt.tinhPTBac2(0, 0, 0);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT4() {
		double[] ex=new double[1];
		ex[0] = 2;
		double[] kq = pt.tinhPTBac2(2, 4, 3);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT5() {
		double[] ex=new double[2];
		ex[0] = -1;
		ex[1] = -4;
		double[] kq = pt.tinhPTBac2(2, 6, 4);
 	}
	@Test
	public void testPT6() {
		double[] ex=new double[1];
		ex[0] = -2;
		double[] kq = pt.tinhPTBac2(1, 4, 4);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT7() {
		double[] ex=new double[1];
		ex[0] = -1;
		double[] kq = pt.tinhPTBac2(0, 5, 2);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT8() {
		double[] ex=new double[2];
		ex[0] = -1;
		ex[1] = 4;
		double[] kq = pt.tinhPTBac2(1, 5, 4);
		assertArrayEquals(ex, kq, 0);
	}
	@Test
	public void testPT9() {
		double[] ex=new double[1];
		ex[0] = -1;
		double[] kq = pt.tinhPTBac2(3, -6, 3);
		assertArrayEquals(ex, kq, 0);
	}	
	@Test
	public void testPT10() {
		double[] ex=new double[1];
		ex[0] = -1;
		double[] kq = pt.tinhPTBac2(0, 4, 4);
		assertArrayEquals(ex, kq, 0);
	}	
}
