package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

import KimHien.TamGiac;

public class TestTamGiac {
	TamGiac tg = new TamGiac();
	@Test
	public void testTG1() {
		boolean kq = tg.tinhTamGiac(1, 2, 4);
		assertTrue(kq);;
	}
	@Test
	public void testTG2() {
		boolean kq = tg.tinhTamGiac(2, 3, 4);
		assertTrue(kq);;
	}
	@Test
	public void testTG3() {
		boolean kq = tg.tinhTamGiac(3, 1, 5);
		assertTrue(kq);;
	}
	@Test
	public void testTG4() {
		boolean kq = tg.tinhTamGiac(4, 5, 6);
		assertTrue(kq);;
	}
	@Test
	public void testTG5() {
		boolean kq = tg.tinhTamGiac(10, 5, 20);
		assertTrue(kq);;
	}
	@Test
	public void testTG6() {
		boolean kq = tg.tinhTamGiac(1, 1, 1);
		assertTrue(kq);;
	}
	@Test
	public void testTG7() {
		boolean kq = tg.tinhTamGiac(2, 1, 4);
		assertTrue(kq);;
	}
	@Test
	public void testTG8() {
		boolean kq = tg.tinhTamGiac(5, 10, 8);
		assertTrue(kq);;
	}
	@Test
	public void testTG9() {
		boolean kq = tg.tinhTamGiac(6, 3, 10);
		assertTrue(kq);;
	}
	@Test
	public void testTG10() {
		boolean kq = tg.tinhTamGiac(2, 4, 5);
		assertTrue(kq);;
	}

}
