package KimHien;

public class PTBac2 {

	public double[] tinhPTBac2(int a, int b, int c) {
		double[] kq;
		double x, x2;
		if (a == 0){
			if(b == 0){
				if(c == 0)	{
					kq = new double[1];
					kq[0] = 0;	// vo so nghiem		
				}else{
					kq = new double[1];
					kq[0] = -1;	// vo nghiem	
				}							
			}else {
				x = -c / b;
				kq = new double[1];
				kq[0] = x;
			}			
		}else {
			double denta = b * b - 4 * a * c;
			if (denta < 0){
				kq = new double[1];
				kq[0] = -1; // vo  nghiem
			}		
			else if (denta == 0){
				x = -b / (2 * a);
				kq = new double[1];
				kq[0] = x;
			}else {
				x = (-b + Math.sqrt(denta)) / (2 * a);
				x2 = (-b - Math.sqrt(denta)) / (2 * a);
				kq = new double[2];
				kq[0] = x;
				kq[1] = x2;
			}
		}		
		return kq;		
	}
	public static void main(String[] args) {
		
	}
}
