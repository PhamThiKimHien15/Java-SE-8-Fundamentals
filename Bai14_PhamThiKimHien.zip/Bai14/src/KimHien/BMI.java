package KimHien;

public class BMI {
	public double tinhBMI(double chieuCao, double canNang) {
		double BMI = canNang / (chieuCao * chieuCao);
		return BMI;
	}
	public static void main(String[] args) {
		
	}
}
