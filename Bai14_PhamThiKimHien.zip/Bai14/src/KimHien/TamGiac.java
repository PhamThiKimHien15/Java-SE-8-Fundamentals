package KimHien;

public class TamGiac {

	public boolean tinhTamGiac(int a, int b, int c) {
		boolean laTamGiac = (a + b) > c && (b + c) > a && (c + a) > b;
		return laTamGiac;
	}
	public static void main(String[] args) {
		
	}
}
