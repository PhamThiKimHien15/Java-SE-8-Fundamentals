package KimHien;

public class Luong {

	public double tinhLuong(double heSoLuong, double luongCoBan, double troCap, double thuong) {
		double tienLuong = heSoLuong*luongCoBan + troCap + thuong;
		return tienLuong;
	}
	public static void main(String[] args) {
		
	}
}
