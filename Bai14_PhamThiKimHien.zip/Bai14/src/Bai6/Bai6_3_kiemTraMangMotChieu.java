package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai6_3_kiemTraMangMotChieu {

	public static void xuatMang(int[] arr) {
		String rs = "";
		for (int value : arr) {
			rs += value + " ";
		}
		System.out.println("Mang da nhap: " + rs);
	}
	public static String kiemTraTinhTangGiam(int[] arr) {
		String kq;
		int count = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					count++;
				}
			}
		}
		if (count == 0) {
			kq = "Mang tang dan";
		} else {
			int count2 = 0;
			for (int i = arr.length - 1; i > 0; i--) {
				for (int j = i - 1; j >= 0; j--) {
					if (arr[i] > arr[j]) {
						count2++;
					}
				}
			}
			if (count2 == 0) {
				kq = "Mang giam dan";
			} else {
				kq = "Mang khong co sap xep thu tu";
			}
		}
		return kq;
	}
	
	// tim phan tu dau tien trong mang co tan cung la 6
	public static void timX(int[] arr, int n) {
		for (int i = 0; i < n; i++) {
			if (arr[i] % 10 == 6) {
				System.out.println("Phan tu dau tien trong mang co tan cung la 6: " + arr[i]);
				break;
			}
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so phan tu muon nhap: ");
		int n = Integer.parseInt(nhap.readLine());
		int[] arr = new int[n];
		// nhap mang
		for (int i = 0; i < n; i++) {
			System.out.println("Nhap phan tu thu " + (i + 1));
			arr[i] = Integer.parseInt(nhap.readLine());
		}
		xuatMang(arr);
		kiemTraTinhTangGiam(arr);
		timX(arr, n);
	}
}
