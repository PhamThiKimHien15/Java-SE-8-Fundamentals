package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Bai6_1_xuLyMangNgauNhien {

	public static void nhapMang(int[] arr, int n) {
		Random random = new Random();
		for (int i = 0; i < n; i++) {
			arr[i] = random.nextInt(10);
		}
	}

	public static void xuatMang(int[] arr) {
		String rs = "";
		for (int value : arr) {
			rs += value + " ";
		}
		System.out.println("Mang ngau nhien: " + rs);
	}

	public static int tong(int n, int[] arr) {
		int tong = 0;
		for (int i = 0; i < n; i++) {
			tong += arr[i];
		}
		return tong;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so phan tu muon nhap: ");
		int n = Integer.parseInt(nhap.readLine());
		int[] arr = new int[n];
		nhapMang(arr, n);
		xuatMang(arr);
		int tong = tong(n, arr);
		System.out.println("Tong = " + tong);
	}
}
