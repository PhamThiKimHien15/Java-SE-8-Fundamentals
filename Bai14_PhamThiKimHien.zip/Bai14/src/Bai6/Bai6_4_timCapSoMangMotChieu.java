package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai6_4_timCapSoMangMotChieu {

	public static void xuatMang(int[] arr) {
		String rs = "";
		for (int value : arr) {
			rs += value + " ";
		}
		System.out.println("Mang da nhap: " + rs);
	}
	public static void quanHeChiaHet(int[] arr, int n) {
		System.out.println("Cac cap so co quan he chia het: ");
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (arr[i] % arr[j] == 0 || arr[j] % arr[i] == 0) {
					System.out.print(arr[i] + "&" + arr[j] + "\t");
				}
			}
		}
	}
	public static void quanHeGap2Lan(int[] arr, int n) {
		System.out.println("\nCac cap so co quan he gap 2 lan:");
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (arr[i] == 2 * arr[j] || arr[j] == 2 * arr[i]) {
					System.out.print(arr[i] + "&" + arr[j] + "\t");
				}
			}
		}
	}
	public static void tongLa8(int[] arr, int n) {
		System.out.println("\nCac cap so co tong bang 8:");
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (arr[i] + arr[j] == 8) {
					System.out.print(arr[i] + "&" + arr[j] + "\t");
				}
			}
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so phan tu muon nhap: ");
		int n = Integer.parseInt(nhap.readLine());
		int[] arr = new int[n];
		// nhap mang
		for (int i = 0; i < n; i++) {
			System.out.println("Nhap phan tu thu " + (i + 1));
			arr[i] = Integer.parseInt(nhap.readLine());
		}
		xuatMang(arr);
		quanHeChiaHet(arr, n);
		quanHeGap2Lan(arr, n);
		tongLa8(arr, n);
	}
}
