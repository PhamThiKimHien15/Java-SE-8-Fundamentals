package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Bai6_6_xuLyMaTranVuong {
	
	// nhap phan tu ngau nhien < 20
	public static void nhapMang(int[][] arr, int n) {
		Random random = new Random();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				arr[i][j] = random.nextInt(20);
			}
		}
	}
	public static void xuatMang(int[][] arr, int n) {
		System.out.println("Mang 2 chieu: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print("\t" + arr[i][j]);
			}
			System.out.print("\n");
		}
	}
	public static void tongDCheoChinh(int[][] arr, int n) {
		int s = 0;
		for (int i = 0; i < n; i++) {
			s += arr[i][i];
		}
		System.out.println("tong gia tri tren duong cheo chinh = " + s);
	}
	public static void minMax(int[][] arr, int n) {
		int min = arr[0][0];
		int max = arr[0][0];
		for (int i = 0; i < n; i++) {
			if (min > arr[i][i]) {
				min = arr[i][i];
			}
			if (max < arr[i][i]) {
				max = arr[i][i];
			}
		}
		System.out.println("Min = " + min);
		System.out.println("Max = " + max);
	}
	public static void soNT(int[][] arr, int n) {
		System.out.println("Cac so nguyen to: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				int dem = 0;
				for (int f = 2; f < Math.sqrt(arr[i][j]); f++) {
					if (arr[i][j] % f == 0) {
						dem++;
					}
				}
				if (dem == 0) {
					System.out.println(arr[i][j] + "\tVi tri: " + i + " " + j);
				}
			}
		}
	}
	public static void doiXungDCheoChinh(int[][] arrb, int m) {
		int doiXung = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				if (arrb[i][j] != arrb[j][i]) {
					doiXung++;
				}
			}
		}
		if (doiXung == 0) {
			System.out.println("Ma tran nay doi xung");
		} else {
			System.out.println("Ma tran nay khong doi xung");
		}
	}
	public static void nhapMangC(int[][] arr, int[][] arrb, int[][] arrc, int m) {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				arrc[i][j] = arr[i][j] + arrb[i][j];
			}
		}
	}
	public static void tangGiamCotK(int[][] arrc, int m, int k) {
		System.out.println("Phan tu cot k la: ");
		int demTang = 0, demGiam = 0;
		for (int i = 0; i < m - 1; i++) {
			System.out.println(arrc[i][k]);
			if (arrc[i][k] > arrc[i + 1][k]) {
				demGiam++;
			}
		}
		for (int i = 0; i < m - 1; i++) {
			System.out.println(arrc[i][k]);
			if (arrc[i][k] < arrc[i + 1][k]) {
				demTang++;
			}
		}
		if (demGiam == (m - 1)) {
			System.out.println("cot " + k + " giam dan");
		} else if (demTang == (m - 1)) {
			System.out.println("cot " + k + " tang dan");
		}else{
			System.out.println("cot " + k + " khong tang / giam");
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("--------------Ma tran a--------------------");
		System.out.println("nhap so dong: ");
		int m = Integer.parseInt(nhap.readLine());
		int[][] arr = new int[m][m];
		nhapMang(arr, m);
		xuatMang(arr, m);
		tongDCheoChinh(arr, m);
		// min, max tren duong cheo chinh
		minMax(arr, m);
		// vi tri & gia tri tat ca cac so nguyen to
		soNT(arr, m);
		
		
		System.out.println("-------------Ma tran b -------------------");
		int[][] arrb = new int[m][m];
		// nhap phan tu
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("Nhap a[" + i + "][" + j + "] = ");
				arr[i][j] = Integer.parseInt(nhap.readLine());
			}
		}
		xuatMang(arrb, m);
		doiXungDCheoChinh(arrb, m);  // doi xung qua duong cheo chinh
		
		
		System.out.println("-------------------------Ma tran c------------------");
		int[][] arrc = new int[m][m];
		nhapMangC(arr, arrb, arrc, m);
		xuatMang(arrc, m);
		// phan tu cua cot k tang hay giam
		System.out.println("nhap cot k: ");
		int k = Integer.parseInt(nhap.readLine());
		tangGiamCotK(arrc, m, k);
	}
}
