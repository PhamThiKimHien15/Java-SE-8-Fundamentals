package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Bai6_5_xuLyMangHaiChieu {

	public static void xuatMang(int[][] arr, int n, int m) {
		System.out.println("Mang 2 chieu: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("\t" + arr[i][j]);
			}
			System.out.print("\n");
		}
	}
	public static int demChan(int[][] arr, int n, int m) {
		int dem = 0; 
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < m; j++) { 
				if(arr[i][j] % 2 == 0)
					dem++; 				
			}
		}
		return dem;
	}
	public static int demLe(int[][] arr, int n, int m) {
		int dem = 0; 
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < m; j++) { 
				if(arr[i][j] % 2 != 0)
					dem++; 			 
			}
		}
		return dem;
	}
	public static void trungBinh(int[][] arr, int n, int m) {
		float tongChan = 0; 
		float tongLe = 0; 
		float tBChan = 0, tBLe = 0; 
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < m; j++) { 
				if(arr[i][j] % 2 == 0){ 
					tongChan += arr[i][j]; 
				}else{
					tongLe += arr[i][j]; 
				} 
			} 
		 } 
		 int demChan = demChan(arr, n, m);
		 int demLe = demLe(arr, n, m);
		 tBChan = (float)(tongChan/demChan); 
		 tBLe = (float)(tongLe/demLe);
		 System.out.println("Gia tri TB cua phan tu chan trong mang: " + String.format("%.2f", tBChan) );
		 System.out.println("Gia tri TB cua phan tu le trong mang: " + String.format("%.2f", tBLe));
	}
	public static void maxMin(int[][] arr, int n, int m) {
		int min = arr[0][0]; 
		int viTriMinDong = 0; 
		int viTriMinCot = 0; 
		int viTriMaxDong = 0; 
		int viTriMaxCot = 0; 
		int max = arr[0][0]; 
		for (int i = 0; i < n; i++) { 
			for (int j = 0; j < m; j++){ 
				if(min > arr[i][j]){ 
					min = arr[i][j]; 
					viTriMinDong=i; 
					viTriMinCot = j; 
				} 
				if (max < arr[i][j]){ 
					max = arr[i][j]; 
					viTriMinDong=i;
					viTriMinCot = j; 
				} 
			} 
		} 
		System.out.print("\nMax = " + max + "\tVi tri = " + viTriMinDong + " " + viTriMinCot);
		System.out.print("\nMin = " + min + "\tVi tri = " + viTriMaxDong + " " + viTriMaxCot);
	}
	public static void xuatHienNhieuNhat(int[][] arr, int n, int m) {
		int[] mangTam = new int[m * n];
		int vt = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				mangTam[vt] = arr[i][j];
				vt++;
			}
		}
		int max = 0;
		int tam = -1, dem;
		Arrays.sort(mangTam);
		for (int i = 0; i < mangTam.length - 1; i++) {
			dem = 0;
			for (int j = i + 1; j < mangTam.length; j++) {
				if (mangTam[i] == mangTam[j]) {
					dem++;
					if (dem > max) {
						max = dem;
						tam = mangTam[i];
					}
				}
			}
		}
		System.out.print("\nPhan tu xuat hien nhieu nhat: " + tam);
	}
	public static void kiemTraPhanTuAm(int[][] arr, int n, int m) {
		int demNhoHon0 = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] < 0) {
					demNhoHon0++;
				}
			}
		}
		if (demNhoHon0 != 0) {
			System.out.println("\nMang nay co phan tu am");
		} else {
			System.out.println("\nMang nay khong co phan tu am");
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("nhap so dong: ");
		int n = Integer.parseInt(nhap.readLine());
		System.out.println("nhap so cot: ");
		int m = Integer.parseInt(nhap.readLine());
		int[][] arr = new int[n][m];
		// nhap phan tu
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print("Nhap a[" + i + "][" + j + "] = ");
				arr[i][j] = Integer.parseInt(nhap.readLine());
			}
		}
		xuatMang(arr, n, m);
		System.out.println("So phan tu chan: "+ demChan(arr, n, m));
		System.out.println("So phan tu le: "+ demLe(arr, n, m));
		trungBinh(arr, n, m);
		maxMin(arr, n, m);
		xuatHienNhieuNhat(arr, n, m);
		kiemTraPhanTuAm(arr, n, m);
		
	}
}
