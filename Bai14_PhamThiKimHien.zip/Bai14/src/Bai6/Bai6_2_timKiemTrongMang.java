package Bai6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Bai6_2_timKiemTrongMang {

	public static void xuatMang(int[] arr) {
		String rs = "";
		for (int value : arr) {
			rs += value + " ";
		}
		System.out.println("Mang da nhap: " + rs);
	}

	public static int timX(int x, int[] arr) {
		Arrays.sort(arr);
		int viTri = Arrays.binarySearch(arr, x);
		if (viTri >= 0)
			return viTri;
		return -1;
	}

	public static void nhoHonX(int[] arr, int n, int x) {
		int count = 0;
		for (int i = 0; i < n; i++) {
			if (x < arr[i]) {
				count++;
			}
		}
		if (count != 0) {
			System.out.println(x + " khong lon hon tat ca cac phan tu trong mang ");
		} else {
			System.out.println(x + " lon hon tat ca cac phan tu trong mang ");
		}
	}

	public static void lonHonX(int[] arr, int n, int x) {
		System.out.println("tat ca cac so lon hon " + x + " la: ");
		for (int i = 0; i < n; i++) {
			if (x < arr[i]) {
				System.out.println(arr[i]);
			}
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so phan tu muon nhap: ");
		int n = Integer.parseInt(nhap.readLine());
		int[] arr = new int[n];
		// nhap mang
		for (int i = 0; i < n; i++) {
			System.out.println("Nhap phan tu thu " + (i + 1));
			arr[i] = Integer.parseInt(nhap.readLine());
		}
		xuatMang(arr);
		System.out.println("Nhap x: ");
		int x = Integer.parseInt(nhap.readLine());
		// x co xuat hien trong mang khong
		int viTri = timX(x, arr);
		if (viTri != -1) {
			System.out.println(x + " xuat hien trong mang tai vi tri " + viTri);
		} else {
			System.out.println(x + " khong nam trong mang");
		}
		nhoHonX(arr, n, x);
		lonHonX(arr, n, x);
	}
}
