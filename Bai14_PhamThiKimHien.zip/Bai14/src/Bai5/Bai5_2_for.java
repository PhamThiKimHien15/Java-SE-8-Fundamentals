package Bai5;
import java.util.Scanner;

public class Bai5_2_for {

	public static double tinhA(int n, double x) {
		double a1 = 1, a2 = 1;
		a1 = (double) Math.pow((Math.pow(x, 2) + x + 1), n);
		a2 = (double) Math.pow((Math.pow(x, 2) - x + 1), n);
		return a2;
	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		System.out.println("Nhap x: ");
		float x = sc.nextFloat();
		float a1 = 1, a2 = 1;
		double a, A;
		for (int i = 1; i <= n; i++) {
			a1 *= Math.pow(x, 2) + x + 1;
			a2 *= Math.pow(x, 2) - x + 1;
		}
		a = a1 + a2;
		System.out.println("Cach viet thong thuong: A = (x^2 + x + 1)^n + (x^2 -x +1)^n = " + a);
		// viet theo ham
		A = tinhA(n, x);
		System.out.println("Cach viet function: A = (x^2 + x + 1)^n + (x^2 -x +1)^n = " + A);

	}
}
