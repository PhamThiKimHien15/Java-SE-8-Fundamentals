package Bai5;
import java.util.Scanner;

public class Bai5_9_for {

	public static void giaiThua(int n) {
		double s = 1, s2 = 1;
		for (int i = 1; i <= n; i++) {
			s *= i;
			if (i % 2 == 0 && n % 2 == 0) {
				s2 *= i;
			} else if (i % 2 != 0 && n % 2 != 0) {
				s2 *= i;
			}
		}
		System.out.println("n! = " + s);
		System.out.println("n!! = " + s2);
	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		giaiThua(n);
	}
}
