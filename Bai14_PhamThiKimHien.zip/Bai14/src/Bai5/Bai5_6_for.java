package Bai5;
import java.util.Scanner;
import java.util.Stack;

import javax.print.DocFlavor.STRING;

public class Bai5_6_for {
	
	public static void doiThapSangNhiPhan(int n){
		Stack s = new Stack();
		int du;
		for (int i = n; i > 0; ){
			du = i % 2;
			s.push(du);
			i = i / 2;
		}
		while (!s.isEmpty()){
			System.out.println(s.peek());
			s.pop();
		}
	}
	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		doiThapSangNhiPhan(n);				
	}
}
