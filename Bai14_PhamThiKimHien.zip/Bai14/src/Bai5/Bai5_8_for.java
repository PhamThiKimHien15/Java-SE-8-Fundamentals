package Bai5;
import java.util.Scanner;

public class Bai5_8_for {

	public static void bangCuuChuong(int n, int a) {
		int s;
		for (int i = n; i <= a; i++) {
			for (int j = 1; j < 10; j++) {
				s = i * j;
				System.out.println(i + " x " + j + " = " + s);
			}
			System.out.println("\t");
		}
	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Cuu chuong tu: ");
		int n = sc.nextInt();
		System.out.println("Den cuu chuong: ");
		int a = sc.nextInt();
		bangCuuChuong(n, a);
	}
}
