package Bai5;
import java.util.Scanner;
import java.util.Stack;

import org.xml.sax.ext.LexicalHandler;

public class Bai5_7_for {
 
	public static void doiNhiSangThapPhan(String n) {
		int thapPhan = 0;
		for (int i = 0; i < n.length(); i++) {
			if (n.charAt(i) == '1') {
				int t = 1;
				for (int j = 0; j < n.length() - 1 - i; j++)
					t *= 2;
				thapPhan += t;
			}
		}
		System.out.println(thapPhan);
	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n: ");
		String n = sc.nextLine();
		doiNhiSangThapPhan(n);
	}
}
