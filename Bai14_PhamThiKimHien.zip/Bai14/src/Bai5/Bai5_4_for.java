package Bai5;
import java.util.Scanner;

public class Bai5_4_for {

	public static String tinh(int n) {
		int A=0, B=0 ,C=1, D=1;
		for (int i = 1; i <= n; i++){
			if(i % 2 == 1){
				A += i;
			}else {
				B += i;
			}
			C *= i;
			if(i % 3 == 0){
				D *= i;
			}
		}
		if (D == 1)
			D = 0;
		return ("A = " + A + "\nB = " + B + "\nC = " + C + "\nD = " + D);
	}
	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		tinh(n);	
	}
}
