package Bai5;
import java.io.IOError;
import java.io.IOException;
import java.util.Scanner;

public class Bai5_3_for {

	public static String soNT(int x) {
		String kq;
		float a1 = 1, a2 = 1;
		int count = 0;
		if(x > 1){
			for (int i=1; i<= Math.sqrt(x); i++){
				if(x % i == 0){
					count++;				
				}			
			}
		}		
		if(count == 1){
			kq="La SNT";
		}else {
			kq="Khong la SNT";
		}
		return kq;
	}
	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		try {
			System.out.println("Nhap x: ");
			int x = sc.nextInt();
			soNT(x);
		} catch (NumberFormatException e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
				
	}
}
