package Bai5;
import java.util.Scanner;

public class Bai5_1_for {

	public static double tinhS(int n, double x) {
		double s = 1;			
		s = (double) Math.pow((Math.pow(x, 2) + 1), n);
						
		return s;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		System.out.println("Nhap x: ");
		double x = sc.nextDouble();
		double S = 1;
		for (int i = 1; i <= n; i++) {
			S *= Math.pow(x, 2) + 1;
		}
		System.out.println("Cach viet thong thuong: S = (x^2 + 1)^n = " + S);
		// viet theo ham
		double s = tinhS(n, x);
		System.out.println("Cach viet function: S = (x^2 + 1)^n = " + s);
	}
}
