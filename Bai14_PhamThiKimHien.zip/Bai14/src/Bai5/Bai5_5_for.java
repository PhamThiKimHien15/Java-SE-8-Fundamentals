package Bai5;
import java.util.Scanner;

public class Bai5_5_for {
	
	public static int tongNT(int n) {
		int s = 1;
		for (int i = 2; i <= n; i++){
			int count = 0;
			for (int j = 1; j <= Math.sqrt(i); j++){
				if(i % j == 0){
					count ++;
				}
			}
			if(count == 1){
				s += i;
			}
		}
		return s;
	}
	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		System.out.println("Nhap n: ");
		int n = sc.nextInt();
		int tongNT = tongNT(n);
		System.out.println("Tong cac so nguyen to: " + tongNT);
		
	}
}
