package Bai7;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai7_4_tinhNamAmLich {

	public static String tinhCan(int nam) {
		while (nam >= 10) {
			nam %= 10;
		}
		String can = "";
		switch (nam) {
		case 0:
			can = "Canh";
			break;
		case 1:
			can = "Tan";
			break;
		case 2:
			can = "Nham";
			break;
		case 3:
			can = "Quy";
			break;
		case 4:
			can = "Giap";
			break;
		case 5:
			can = "At";
			break;
		case 6:
			can = "Binh";
			break;
		case 7:
			can = "Dinh";
			break;
		case 8:
			can = "Mau";
			break;
		case 9:
			can = "Ky";
			break;
		default:
			break;
		}
		return can;
	}

	public static String tinhChi(int nam) {
		while (nam >= 12) {
			nam %= 12;
		}
		String chi = "";
		switch (nam) {
		case 0:
			chi = "Than";
			break;
		case 1:
			chi = "Dau";
			break;
		case 2:
			chi = "Tuat";
			break;
		case 3:
			chi = "Hoi";
			break;
		case 4:
			chi = "Ty";
			break;
		case 5:
			chi = "Suu";
			break;
		case 6:
			chi = "Dan";
			break;
		case 7:
			chi = "Mao";
			break;
		case 8:
			chi = "Thin";
			break;
		case 9:
			chi = "Ty";
			break;
		case 10:
			chi = "Ngo";
			break;
		case 11:
			chi = "Mui";
			break;
		default:
			break;
		}
		return chi;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("nhap nam sinh: ");
		int nam = Integer.parseInt(nhap.readLine());
		String can = tinhCan(nam);
		String chi = tinhChi(nam);
		System.out.println(can + chi);
	}
}
