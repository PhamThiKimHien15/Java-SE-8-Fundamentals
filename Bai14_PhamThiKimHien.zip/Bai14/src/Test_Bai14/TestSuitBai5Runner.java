package Test_Bai14;
import org.junit.*;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
public class TestSuitBai5Runner {

	public static void main (String[] args)
	{
		Result result = JUnitCore.runClasses(TestSuitBai5.class);
		for(Failure fail: result.getFailures())
		{
			System.out.println(fail.toString());
		}
		System.out.println(result.wasSuccessful());
	}
}
