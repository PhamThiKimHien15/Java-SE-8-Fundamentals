package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai5.Bai5_2_for;

public class Bai5_2 {

	Bai5_2_for bai5 = new Bai5_2_for();
	@Test
	public void testtinhA1() {
		double ex = 1;
		double ac = bai5.tinhA(0, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA2() {
		double ex = 1;
		double ac = bai5.tinhA(1, 1);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA3() {
		double ex = 0.1111;
		double ac = bai5.tinhA(-2, 2);
		assertEquals(ex, ac, 0.0001);
	}
	@Test
	public void testtinhA4() {
		double ex = 59049;
		double ac = bai5.tinhA(10, 2);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA5() {
		double ex = 2.5;
		double ac = bai5.tinhA(2, Math.sqrt(2));
		assertEquals(ex, ac, 0.1);
	}
	@Test
	public void testtinhA6() {
		double ex = 0;
		double ac = bai5.tinhA(0, 1);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA7() {
		double ex = 0;
		double ac = bai5.tinhA(0, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA8() {
		double ex = 0;
		double ac = bai5.tinhA(2, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA9() {
		double ex = 9;
		double ac = bai5.tinhA(-2, 2);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testtinhA10() {
		double ex = 0.37;
		double ac = bai5.tinhA(-2, Math.sqrt(2));
		assertEquals(ex, ac, 0.01);
	}
}
