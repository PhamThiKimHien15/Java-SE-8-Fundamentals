package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai5.Bai5_1_for;

public class Bai5_1 {

	Bai5_1_for bai5 = new Bai5_1_for();
	@Test
	public void testTimS1() {
		double ex = 1;
		double ac = bai5.tinhS(0, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS2() {
		double ex = 2;
		double ac = bai5.tinhS(1, 1);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS3() {
		double ex = 0.04;
		double ac = bai5.tinhS(-2, 2);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS4() {
		double ex = 9765625;
		double ac = bai5.tinhS(10, 2);
		assertEquals(ex, ac, 0);
	}@Test
	public void testTimS5() {
		double ex = 9;
		double ac = bai5.tinhS(2, Math.sqrt(2));
		assertEquals(ex, ac, 0.001);
	}@Test
	public void testTimS6() {
		double ex = 0;
		double ac = bai5.tinhS(0, 1);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS7() {
		double ex = 0;
		double ac = bai5.tinhS(0, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS8() {
		double ex = 0;
		double ac = bai5.tinhS(2, 0);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS9() {
		double ex = 25;
		double ac = bai5.tinhS(-2, 2);
		assertEquals(ex, ac, 0);
	}
	@Test
	public void testTimS10() {
		double ex = 9;
		double ac = bai5.tinhS(-2, Math.sqrt(2));
		assertEquals(ex, ac, 0);
	}
	
	
	
}
