package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai5.Bai5_4_for;

public class Bai5_4 {

	Bai5_4_for bai5 = new Bai5_4_for();
	@Test
	public void testBT1() {
		String ex = "A = 25\nB = 20\nC = 362880\nD = 162";
		String ac = bai5.tinh(9);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT2() {
		String ex = "A = 49\nB = 42\nC = 1932053504\nD = 1944";
		String ac = bai5.tinh(13);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT3() {
		String ex = "A = 1\nB = 2\nC = 2\nD = 0";
		String ac = bai5.tinh(2);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT4() {
		String ex = "A = 36\nB = 42\nC = 479001600\nD = 1944";
		String ac = bai5.tinh(12);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT5() {
		String ex = "A = 4\nB = 6\nC = 24\nD = 3";
		String ac = bai5.tinh(4);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT6() {
		String ex = "A = 64\nB = 64\nC = 5040\nD = 5040";
		String ac = bai5.tinh(7);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT7() {
		String ex = "A = 8\nB = 5\nC = 24\nD = 24";
		String ac = bai5.tinh(5);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT8() {
		String ex = "A = 35\nB = 30\nC = 362880\nD = 362880";
		String ac = bai5.tinh(10);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT9() {
		String ex = "A = 16\nB = 30\nC = 40320\nD = 18";
		String ac = bai5.tinh(8);
		assertEquals(ex, ac);
	}
	@Test
	public void testBT10() {
		String ex = "A = 37\nB = 30\nC = 39916800\nD = 162";
		String ac = bai5.tinh(4);
		assertEquals(ex, ac);
	}	
	
}
