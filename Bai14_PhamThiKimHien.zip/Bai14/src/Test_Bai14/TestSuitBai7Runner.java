package Test_Bai14;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestSuitBai7Runner {

	public static void main(String[] args){
		Result re = JUnitCore.runClasses(TestSuitBai7.class);
		for(Failure fa : re.getFailures()){
			System.out.println(fa.toString());
		}
	}
}
