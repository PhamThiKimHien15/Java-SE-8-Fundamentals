package Test_Bai14;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Bai5_1.class, Bai5_2.class, Bai5_3.class, Bai5_4.class })
public class TestSuitBai5 {

}
