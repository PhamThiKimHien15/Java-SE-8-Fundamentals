package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai6.Bai6_3_kiemTraMangMotChieu;

public class Bai6_3 {

	Bai6_3_kiemTraMangMotChieu bai6 = new Bai6_3_kiemTraMangMotChieu();
	@Test
	public void testKTMang1Chieu1() {
		String ex = "Mang tang dan";
		int[] mang = {2,4,6,7};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu2() {
		String ex = "Mang giam dan";
		int[] mang = {7,6,4,2};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu3() {
		String ex = "Mang khong co sap xep thu tu";
		int[] mang = {3,6, 5,7};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu4() {
		String ex = "Mang tang dan";
		int[] mang = {2,4,9,10};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu5() {
		String ex = "Mang giam dan";
		int[] mang = {9,7,5,4};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu6() {
		String ex = "Mang giam dan";
		int[] mang = {2,4,6,7};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu7() {
		String ex = "Mang tang dan";
		int[] mang = {7,6,4,2};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu8() {
		String ex = "Mang khong co sap xep thu tu";
		int[] mang = {7,6,4,2};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu9() {
		String ex = "Mang giam dan";
		int[] mang = {4,6,8,11};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
	@Test
	public void testKTMang1Chieu10() {
		String ex = "Mang tang dan";
		int[] mang = {5,4,3,1};
		String ac = bai6.kiemTraTinhTangGiam(mang);
		assertEquals(ex, ac);
	}
}
