package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai5.Bai5_3_for;

public class Bai5_3 {

	Bai5_3_for bai5 = new Bai5_3_for();
	@Test
	public void testSNT1() {
		String ex="La SNT";
		String ac = bai5.soNT(7);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT2() {
		String ex="La SNT";
		String ac = bai5.soNT(3);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT3() {
		String ex="La SNT";
		String ac = bai5.soNT(19);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT4() {
		String ex="La SNT";
		String ac = bai5.soNT(2);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT5() {
		String ex="La SNT";
		String ac = bai5.soNT(283);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT6() {
		String ex="La SNT";
		String ac = bai5.soNT(1);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT7() {
		String ex="La SNT";
		String ac = bai5.soNT(-1);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT8() {
		String ex="La SNT";
		String ac = bai5.soNT(-9);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT9() {
		String ex="La SNT";
		String ac = bai5.soNT(8);
		assertEquals(ex, ac);
	}
	@Test
	public void testSNT10() {
		String ex="La SNT";
		String ac = bai5.soNT(240);
		assertEquals(ex, ac);
	}
}
