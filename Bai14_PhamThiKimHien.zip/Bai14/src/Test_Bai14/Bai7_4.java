package Test_Bai14;

import static org.junit.Assert.*;

import org.junit.Test;

import Bai7.Bai7_4_tinhNamAmLich;

public class Bai7_4 {

	Bai7_4_tinhNamAmLich bai7 = new Bai7_4_tinhNamAmLich();
	// Ham tinh can
	@Test
	public void testAmLich1() {
		String ex = "Canh";
		String can = bai7.tinhCan(1990);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich2() {
		String ex = "Ky";
		String can = bai7.tinhCan(1999);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich3() {
		String ex = "Nham";
		String can = bai7.tinhCan(2012);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich4() {
		String ex = "Tan";
		String can = bai7.tinhCan(2001);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich5() {
		String ex = "At";
		String can = bai7.tinhCan(2005);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich6() {
		String ex = "Dinh";
		String can = bai7.tinhCan(1996);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich7() {
		String ex = "Mau";
		String can = bai7.tinhCan(2009);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich8() {
		String ex = "Tan";
		String can = bai7.tinhCan(2000);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich9() {
		String ex = "At";
		String can = bai7.tinhCan(2016);
		assertEquals(ex, can);
	}
	@Test
	public void testAmLich10() {
		String ex = "Canh";
		String can = bai7.tinhCan(2001);
		assertEquals(ex, can);
	}
	// Ham tinh Chi
	@Test
	public void testAmLich11() {
		String ex = "Ngo";
		String chi = bai7.tinhChi(1990);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich12() {
		String ex = "Mao";
		String chi = bai7.tinhChi(1999);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich13() {
		String ex = "Thin";
		String chi = bai7.tinhChi(2012);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich14() {
		String ex = "Ty";
		String chi = bai7.tinhChi(2001);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich15() {
		String ex = "Dau";
		String chi = bai7.tinhChi(2005);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich16() {
		String ex = "Hoi";
		String chi = bai7.tinhChi(1996);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich17() {
		String ex = "Thin";
		String chi = bai7.tinhChi(2011);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich18() {
		String ex = "Mui";
		String chi = bai7.tinhChi(2000);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich19() {
		String ex = "Dau";
		String chi = bai7.tinhChi(2016);
		assertEquals(ex, chi);
	}
	@Test
	public void testAmLich20() {
		String ex = "Ngo";
		String chi = bai7.tinhChi(2001);
		assertEquals(ex, chi);
	}
}
