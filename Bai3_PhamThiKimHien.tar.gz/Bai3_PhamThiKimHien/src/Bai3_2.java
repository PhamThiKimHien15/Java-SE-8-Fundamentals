import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai3_2 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap x: ");
		int x = Integer.parseInt(inp.readLine());
		double s= (float) (1 + x + Math.pow(x,3)/3 + Math.pow(x,5)/5);
		System.out.println("S = 1 + x*x*x/3 + x*x*x*x*x/5 = "+ String.format("%.2f", s));
		
	}

}
