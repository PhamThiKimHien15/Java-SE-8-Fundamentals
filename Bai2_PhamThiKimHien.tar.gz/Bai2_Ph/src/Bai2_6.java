import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_6 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Lai suat 1 nam: ");
		float laiSuat = Float.parseFloat(inp.readLine());
		System.out.println("So tien gui: ");
		int tien = Integer.parseInt(inp.readLine());
		System.out.println("So thang: ");
		int thang = Integer.parseInt(inp.readLine());
		double tienLai = tien * thang * (laiSuat/12);
		double tongTien = tien + tienLai;
		System.out.println("Tien lai: "+ String.format("%.2f", tienLai));
		System.out.println("Tong von va lai: "+ String.format("%.2f", tongTien));
	}
	
}
