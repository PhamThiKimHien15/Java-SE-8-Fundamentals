import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_3 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		final float PI=(float) 3.14;
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("run: \nNhap ban kinh: ");
		float r = Float.parseFloat(inp.readLine());
		double chuVi= 2*r*PI;
		double dienTich = PI*r*r;
		System.out.println("Chu vi: " + String.format("%.2f", chuVi)  + "\nDien tich: " + String.format("%.2f", dienTich));
		
	}

}
