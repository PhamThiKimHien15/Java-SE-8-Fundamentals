import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_7 {

	public static void main(String[] args) throws IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Ten ngoai te muon doi: ");
		String ten = inp.readLine();
		
		System.out.println("Ty gia cua ngoai te: ");
		int tyGia = Integer.parseInt(inp.readLine());
		System.out.println("So ngoai te: ");
		int soNT = Integer.parseInt(inp.readLine());
		double thanhTien = tyGia * soNT;
		if (ten == "USD"){
			System.out.println("Ban dang doi tu: " + ten + " sang VND");
		}
		else{
			System.out.println("Ban dang doi tu: " + ten + "sang USD");
		}
		System.out.println("Thanh tien: " + thanhTien);
		
	}
	
}
