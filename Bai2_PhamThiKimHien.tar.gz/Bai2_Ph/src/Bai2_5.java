import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_5 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap chu vi hinh chu nhat: ");
		double chuVi = Double.parseDouble(inp.readLine());
		float r= (float) (chuVi / 5);
		double dienTich = r * 1.5 * r;
		System.out.println("Dien tich: "+String.format("%.2f", dienTich));
	}
	
}
