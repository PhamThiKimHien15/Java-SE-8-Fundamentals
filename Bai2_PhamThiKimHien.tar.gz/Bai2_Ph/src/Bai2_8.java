import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_8 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap so luong san pham:");
		int soLuong = Integer.parseInt(inp.readLine());
		System.out.println("Nhap tien cong cua 1 san pham:");
		int tien = Integer.parseInt(inp.readLine());
		System.out.println("Nhap tien thuong: ");
		int tienThuong = Integer.parseInt(inp.readLine());
		System.out.println("nhap so con: ");
		int soCon = Integer.parseInt(inp.readLine());
		double tienLuong = soLuong*tien;
		double phuCap = soCon*200000;
		double thucLinh = tien + tienThuong + phuCap;
		System.out.println("Tien luong: "+ String.format("%.2f", tienLuong));
		System.out.println("Phu Cap: "+ String.format("%.2f", phuCap));
		System.out.println("Thuc linh: "+ String.format("%.2f", thucLinh));
	}
	
}
