import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_2 {
	
	public static void main(String[] args) throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("run: \nNhap so luong: ");
		int soLuong = Integer.parseInt(input.readLine());
		System.out.println("Nhap don gia: ");
		int donGia= Integer.parseInt(input.readLine());
		int thanhTien = soLuong * donGia;
		System.out.println("Thanh tien = " + thanhTien);
		
	}

}
