import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Bai2_4 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		final float PI = (float) 3.14;
		BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap dien tich cua hinh tron: ");
		double dienTich = Double.parseDouble(inp.readLine());
		float r = (float) Math.sqrt(dienTich / PI);
		System.out.println("Ban kinh hinh tron la: " + String.format("%.2f", r));
		
	}

	
	
}
